Page({
    data: {
        shareData: {
            title: '',
            systemInfo: "",
            url:"",
            type:""
        }
    },
    onLoad: function (options) {
        let _this = this;
        _this.setData({
            url: 'https://cs.spon.com.cn/webview/webview.html'
        });
        wx.showShareMenu({
            withShareTicket: false
        })

        wx.setNavigationBarTitle({
            title: "工具软件下载",
        })

    }
})