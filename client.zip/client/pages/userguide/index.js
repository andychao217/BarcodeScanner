Page({
    data: {
        shareData: {
            id:"",
            name: '',
            systemInfo: "",
            url:"",
            type:""
        },
        display_web:false,
        display_404: true
    },
    onLoad: function (options) {
        let _this = this;
        this.setData({
            shareData: {
                id: JSON.parse(options.data).id,
                name: JSON.parse(options.data).name,
                systemInfo: JSON.parse(options.data).systemInfo,
                type: JSON.parse(options.data).type,
                path: '/pages/userhguide/index'
            }
        })

        wx.showShareMenu({
            withShareTicket: false
        })

        wx.setNavigationBarTitle({
            title: this.data.shareData.id,
        })

        if(_this.data.shareData.systemInfo == "iOS"){
            if(_this.data.shareData.type == "instruction"){
                _this.setData({
                    url:'https://cs.spon.com.cn/pdf/instruction/' + _this.data.shareData.id + '用户指南.pdf' + '?t=' + new Date().getTime()
                });
            }else{
                _this.setData({
                    url:'https://cs.spon.com.cn/pdf/installinstruction/' + _this.data.shareData.id + '快速安装指南.pdf'+ '?t=' + new Date().getTime()
                });
            }
        }else{
            let url = "";
            if(_this.data.shareData.type == "instruction"){
                url = 'https://cs.spon.com.cn/pdf/instruction/' + _this.data.shareData.id + '用户指南.pdf';+ '?t=' + new Date().getTime()
            }else{
                url = 'https://cs.spon.com.cn/pdf/installinstruction/' + _this.data.shareData.id + '快速安装指南.pdf'+ '?t=' + new Date().getTime()
            }
            _this.setData({
                url: url
            });
            wx.downloadFile({
                 url: url,
                 success: function (res) {
                     let filePath = res.tempFilePath;
                     wx.openDocument({
                         fileType: 'pdf',
                         filePath: filePath,
                         success: function (res) {
                            console.log('打开文档成功');
                         }
                     })
                 }
            })
        }

    }
})