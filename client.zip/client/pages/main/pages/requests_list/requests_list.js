Page({
  onLoad: function (query) {
    wx.setNavigationBarTitle({
      title: query.id
    })

    wx.setNavigationBarColor({
      frontColor: '#ffffff',
      backgroundColor: '#5a5a5a',
      animation: {
        duration: 400,
        timingFunc: 'easeIn'
      }
    })
    
    var that = this
    wx.request({
      url: 'https://cs.spon.com.cn/json/requests_list/' + query.id + '.json',
      success: function (result) {
        console.log(result)
        that.setData({
          list: result.data
        })
      }
    })
  },
  data: {
    list: []
  },
  bindTap:function(e){
    console.log(e.currentTarget.id)
    var serial = e.currentTarget.id
    wx.navigateTo({
      url: '../result/result?serial=' + serial
    })
  }
})
