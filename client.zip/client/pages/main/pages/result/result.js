var utils = require('../../../../utils/util.js')

Page({
  data: {
    problemType: '',
    deviceType: '',
    difficulty: '',
    problem: '',
    method: '',
    point: '',
    shareData: {
      title: '',
    },
  },
  onLoad: function (query) {
    wx.onUserCaptureScreen(function (res) {
      wx.showToast({
        title: '截屏成功',
        icon: 'success',
        duration: 2000
      })
    })

    wx.setNavigationBarColor({
      frontColor: '#ffffff',
      backgroundColor: '#5a5a5a',
      animation: {
        duration: 400,
        timingFunc: 'easeIn'
      }
    })

    var that = this
    wx.request({
      url: 'https://cs.spon.com.cn/json/results/' + query.serial + '.json',
      success: function (result) {
        console.log(result)
        var problemType = result.data.problemType
        var deviceType = result.data.deviceType
        var difficulty = result.data.difficulty
        var point = result.data.point
        if (problemType == ' '){
          problemType = ''
        }
        if (deviceType == ' ') {
          deviceType = ''
        }
        if (difficulty == ' ') {
          difficulty = ''
        }
        if (point == ' ') {
          point = ''
        }
        that.setData({
          problemType: problemType,
          deviceType: deviceType,
          difficulty: difficulty,
          problem: result.data.problem,
          method: result.data.method,
          point: point,
        })
      }
    })
    wx.setNavigationBarTitle({
      title: query.serial
    })
    that.setData({
      shareData: {
        title: query.serial,
        path: '/pages/main/pages/result/result?serial=' + query.serial
      }
    })
    wx.showShareMenu({
      withShareTicket: true
    })
  },
  onShareAppMessage: function (e) {
    return this.data.shareData
  }
})