var fun_base64 = require('../../utils/base64.js')

Page({
    data: {
        inputShowed: false,
        inputVal: "",
        shareData: {
            title: '',
        },
        list: []
    },
    showInput: function () {
        this.setData({
            inputShowed: false
        });
    },
    hideInput: function () {
        this.setData({
            inputVal: "",
            inputShowed: false
        });
    },
    clearInput: function () {
        this.setData({
            inputVal: ""
        });
    },
    inputTyping: function (e) {
        this.setData({
            inputVal: e.detail.value,
            searchResults:[
                {
                    id:'1',
                    device:'XC-9000',
                    src:'pages/requests_list/requests_list?id=XC-9000'
                },
                {
                    id:'2',
                    device: 'XC-9171',
                    src: 'pages/requests_list/requests_list?id=XC-9171'
                }
            ]
        });
    },
    bindTap:function(e){
        console.log(e.currentTarget.id)
        var id = e.currentTarget.id
        wx.navigateTo({
            url: 'pages/requests_list/requests_list?id=' + id
        })
    },
    kindToggle: function (e) {
        var id = e.currentTarget.id, list = this.data.list;
        for (var i = 0, len = list.length; i < len; ++i) {
            if (list[i].id == id) {
                list[i].open = !list[i].open
            } else {
                list[i].open = false
            }
        }
        this.setData({
            list: list
        });
    },
    onLoad: function () {
        console.log(fun_base64);
        var that = this
        wx.request({
            url: 'https://cs.spon.com.cn/json/list.json',
            success:function(result){
                console.log(result)
                that.setData({
                    list:result.data
                })
            }
        })
        that.setData({
            shareData: {
                title: '世邦产品维护手册',
                path: '/pages/main/index'
            }
        })
        wx.showShareMenu({
            withShareTicket: true
        })
    },
    scanCode:function(e) {
        wx.scanCode({
            success: (res) => {
                // var obj_base64 = new fun_base64.Base64()
                var resultArr = res.result.split(',')
                var id = fun_base64.base64decode(resultArr[1])
                console.log("id => ", id );
                wx.navigateTo({
                    url: 'pages/requests_list/requests_list?id=' + id
                })
            }
        })
    },
    onShareAppMessage: function (e) {
        return this.data.shareData
    }
})