//index.js
//获取应用实例
const app = getApp()

Page({
    data: {
        motto: '世邦产品维护手册',
        userPassword: '',
        shareData: {
            title: '',
        },
    },
    //事件处理函数
    onLoad: function () {
        wx.setNavigationBarTitle({
            title: '技术支持'
        })

        wx.setNavigationBarColor({
            frontColor: '#ffffff',
            backgroundColor: '#1c7dc1',
            animation: {
                duration: 400,
                timingFunc: 'easeIn'
            }
        })

        var userPassword = wx.getStorageSync('userPassword')
        if (userPassword == '800823') {
        }

        this.setData({
            shareData: {
                title: '世邦产品维护手册',
                path: '/pages/support/index'
            }
        })
        wx.showShareMenu({
            withShareTicket: true
        })
    },
    onShareAppMessage: function (e) {
        return this.data.shareData
    },
    passwordInput: function (e) {
        this.setData({
            userPassword: e.detail.value
        })
    },
    loginBtnClick: function (e) {
        var that = this
        if (that.data.userPassword == '800823'){
            wx.navigateTo({
                url: '../main/index'
            })
            wx.setStorage({
                key: 'userPassword',
                data: that.data.userPassword,
            })
        }else{
            wx.showToast({
                title: '密码错误',
                icon: 'loading',
                duration: 800
            });
        }
    }
})
