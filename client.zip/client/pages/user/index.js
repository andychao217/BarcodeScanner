var fun_base64 = require('../../utils/base64.js');
Page({
  data: {
    shareData: {
      title: ''
    },
    background: '/pages/images/bg.png', //背景图片
    video_src: '',
    systemInfo: ''
  },

  onLoad: function() {
    wx.setNavigationBarColor({
      frontColor: '#ffffff',
      backgroundColor: '#1578FE',
      animation: {
        duration: 400,
        timingFunc: 'easeIn'
      }
    });

    let that = this;
    let base64 = wx
      .getFileSystemManager()
      .readFileSync(this.data.background, 'base64');
    this.setData({
      shareData: {
        title: 'SPON产品维护手册',
        path: '/pages/user/index'
      },
      background: 'data:image/png;base64,' + base64,
      video_src: 'https://cs.spon.com.cn/video/SponVideo.MP4'
    });

    wx.showShareMenu({
      withShareTicket: true
    });

    wx.getSystemInfo({
      success: function(res) {
        if (res.system.indexOf('iOS') >= 0) {
          that.setData({
            systemInfo: 'iOS'
          });
        }

        if (res.system.indexOf('Android') >= 0) {
          that.setData({
            systemInfo: 'Android'
          });
        }
      }
    });
  },

  onShareAppMessage: function(e) {
    return this.data.shareData;
  },

  scanCodeUserGuid: function(e) {
    var _this = this;
    wx.scanCode({
      success: res => {
        let that = _this;
        // let resultArr = res.result.split(',');
        // let id = fun_base64.base64decode(resultArr[1]);
        let id = res.result.split('@')[0];
        let name = res.result.split('@')[1];
        let data = {
          id: id,
          name: name,
          systemInfo: that.data.systemInfo,
          type: 'instruction'
        };
        console.log("用户指南")
        console.log(data)
        wx.navigateTo({
          url: "../userguide/index?data=" + JSON.stringify(data) + "?t=" + new Date().getTime()
        });
      }
    });
  },

  quickGuideClick: function(e) {
    var _this = this;
    wx.scanCode({
      success: res => {
        let that = _this;
        // let resultArr = res.result.split(',');
        // let id = fun_base64.base64decode(resultArr[1]);
        let id = res.result.split('@')[0];
        let name = res.result.split('@')[1];
        let data = {
          id: id,
          name:name,
          systemInfo: that.data.systemInfo,
          type: 'installinstruction'
        };
        console.log("快速安装指南")
        console.log(data)
        wx.navigateTo({
          url: '../userguide/index?data=' + JSON.stringify(data) + "?t=" + new Date().getTime()
        });
      }
    });
  },

  textPaste: function() {
    wx.setClipboardData({
        data: 'http://m.spon.com.cn/fwzc.html',
        success: function (res) {
            wx.showToast({
                title: '链接复制成功',
            })
            wx.getClipboardData({    //这个api是把拿到的数据放到电脑系统中的
                success: function (res) {
                    console.log(res.data) // data
                }
            })
        }
    });
    // wx.navigateTo({
    //     url: '../officialwebsite/index'
    // })
  },

  callPhone: function() {
    wx.makePhoneCall({
      phoneNumber: '4008232588'
    });
  }
});
